package com.example.driver_service.model;

public enum AvailabilityStatus {
	AVAILABLE,ON_TRIP,OFF_DUTY
}
