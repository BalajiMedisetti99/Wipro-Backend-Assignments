package com.example.vehicle_service.model;

public enum VehicleType {
	BUS,CAR,VAN,TRUCK
}

enum VehicleStatus{
	AVAILABLE,ON_TRIP,MAINTENANCE
}
