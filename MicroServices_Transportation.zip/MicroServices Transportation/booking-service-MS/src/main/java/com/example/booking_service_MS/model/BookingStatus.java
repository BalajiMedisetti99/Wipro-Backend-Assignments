package com.example.booking_service_MS.model;

public enum BookingStatus {
	PENDING,CONFIRMED,COMPLETED,CANCELLED
}
