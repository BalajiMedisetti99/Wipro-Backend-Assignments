package com.transport.exception;

public class StopNotFoundException extends RuntimeException {
    
	private static final long serialVersionUID = 1L;

	public StopNotFoundException(Long id) {
        super("Stop not found: " + id);
    }
}