package com.transport.exception;

public class TimetableNotFoundException extends RuntimeException {
    
	private static final long serialVersionUID = 1L;

	public TimetableNotFoundException(Long id) {
        super("Timetable not found: " + id);
    }
}
