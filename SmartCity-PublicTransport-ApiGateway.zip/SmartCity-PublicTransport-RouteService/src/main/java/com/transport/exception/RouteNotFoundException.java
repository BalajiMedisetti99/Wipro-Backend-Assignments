package com.transport.exception;

public class RouteNotFoundException extends RuntimeException {
    
	private static final long serialVersionUID = 1L;

	public RouteNotFoundException(Long id) {
        super("Route not found: " + id);
    }
}
