package com.transport.kafka;


import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;


import com.transport.dto.TelemetryDTO;

import com.transport.service.RouteService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RouteKafkaListener {

    private final RouteService routeService;

        @KafkaListener(topics = "vehicle-updates", groupId = "route-service-group")
        public void consumeTelemetry(TelemetryDTO telemetry) {
            
            routeService.updateEtaFromTelemetry(telemetry);
        }
    }