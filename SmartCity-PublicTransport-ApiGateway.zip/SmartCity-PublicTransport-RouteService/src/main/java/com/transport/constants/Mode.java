package com.transport.constants;

public enum Mode {
	
	BUS,
	TRAIN

}
