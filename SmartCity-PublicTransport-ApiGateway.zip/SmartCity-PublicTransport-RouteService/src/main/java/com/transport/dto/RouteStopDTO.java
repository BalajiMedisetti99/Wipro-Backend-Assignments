package com.transport.dto;

import lombok.Data;

@Data
public class RouteStopDTO {
    private Long stopId;
    private String stopName;
    private Double lat;
    private Double lon;
    private Integer sequence;
    private Integer dwellSeconds;
}