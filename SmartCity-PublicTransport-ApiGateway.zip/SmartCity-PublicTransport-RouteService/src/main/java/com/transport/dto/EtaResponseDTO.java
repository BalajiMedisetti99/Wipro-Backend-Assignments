package com.transport.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EtaResponseDTO {
    private Long routeId;
    private Long stopId;
    private int etaSeconds;
}
