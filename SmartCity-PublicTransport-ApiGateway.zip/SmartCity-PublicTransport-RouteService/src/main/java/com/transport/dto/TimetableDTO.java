package com.transport.dto;

import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TimetableDTO {
    private Long id;
    private Long routeId;
    private String serviceDay;
    private LocalTime startTime;
    private LocalTime endTime;
    private int headwaySeconds;
}
