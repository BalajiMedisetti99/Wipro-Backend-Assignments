package com.transport.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.transport.model.Stop;

@Repository
public interface StopRepository extends JpaRepository<Stop, Long> {

   
    @Query(value = "SELECT * FROM stop s WHERE ST_DWithin(ST_SetSRID(ST_MakePoint(:lon,:lat),4326)::geography, ST_SetSRID(ST_MakePoint(s.lon,s.lat),4326)::geography, :radius)", nativeQuery = true)
    List<Stop> findNearby(@Param("lat") double lat, @Param("lon") double lon, @Param("radius") double radiusMeters);
}
