package com.transport.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.transport.constants.Mode;
import com.transport.dto.EtaResponseDTO;
import com.transport.dto.RouteDTO;
import com.transport.dto.RouteStopDTO;
import com.transport.dto.StopDTO;
import com.transport.dto.TelemetryDTO;
import com.transport.dto.TimetableDTO;
import com.transport.exception.RouteNotFoundException;
import com.transport.exception.StopNotFoundException;
import com.transport.exception.TimetableNotFoundException;
import com.transport.model.Route;
import com.transport.model.RouteStop;
import com.transport.model.Stop;
import com.transport.model.Timetable;
import com.transport.repository.RouteRepository;
import com.transport.repository.RouteStopRepository;
import com.transport.repository.StopRepository;
import com.transport.repository.TimetableRepository;
import com.transport.service.RouteService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RouteServiceImpl implements RouteService {

    private final RouteRepository routeRepository;
    private final StopRepository stopRepository;
    private final RouteStopRepository routeStopRepository;
    private final TimetableRepository timetableRepository;
    private final ModelMapper mapper;
    
    private final Map<String, Integer> etaMap = new ConcurrentHashMap<>();

    public Page<RouteDTO> getRoutes(Mode mode, boolean active, Pageable pageable) {
        Page<Route> routes;

        if (mode != null) {
            routes = routeRepository.findByModeAndActive(mode, active, pageable);
        } else {
            routes = routeRepository.findByActive(active, pageable);
        }

        return routes.map(route -> RouteDTO.builder()
                .id(route.getId())
                .name(route.getName())
                .mode(route.getMode().name())
                .active(route.isActive())
                .agencyId(route.getAgencyId())
                .build());
    }

    @Override
    public RouteDTO getRoute(Long id) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new RouteNotFoundException(id));
        return mapper.map(route, RouteDTO.class);
    }

    @Override
    public List<StopDTO> getStopsNear(double lat, double lon, double radius) {
        return stopRepository.findNearby(lat, lon, radius).stream()
                .map(stop -> mapper.map(stop, StopDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<RouteStopDTO> getRouteStops(Long routeId) {
        return routeStopRepository.findByRoute_IdOrderBySequence(routeId).stream()
                .map(rs -> {
                    RouteStopDTO dto = new RouteStopDTO();
                    dto.setStopId(rs.getStop().getId());
                    dto.setStopName(rs.getStop().getName());
                    dto.setLat(rs.getStop().getLat());
                    dto.setLon(rs.getStop().getLon());
                    dto.setSequence(rs.getSequence());
                    dto.setDwellSeconds(rs.getDwellSeconds());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Override
    public List<TimetableDTO> getTimetable(Long routeId, LocalDate serviceDay) {
        List<Timetable> ttList = timetableRepository.findByRouteIdAndServiceDay(routeId, serviceDay);
        if (ttList.isEmpty()) throw new TimetableNotFoundException(routeId);
        return ttList.stream().map(tt -> {
            TimetableDTO dto = mapper.map(tt, TimetableDTO.class);
            dto.setRouteId(tt.getRoute().getId());
            dto.setServiceDay(tt.getServiceDay().toString());
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public RouteDTO addRoute(RouteDTO routeDto) {
        Route route = mapper.map(routeDto, Route.class);
        route = routeRepository.save(route);
        return mapper.map(route, RouteDTO.class);
    }

    @Override
    public RouteDTO updateRoute(Long id, RouteDTO routeDto) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Route not found: " + id));
        mapper.map(routeDto, route);
        route = routeRepository.save(route);
        return mapper.map(route, RouteDTO.class);
    }

    @Override
    public void deleteRoute(Long id) {
        routeRepository.deleteById(id);
    }

    @Override
    public StopDTO addStop(StopDTO stopDto) {
        Stop stop = mapper.map(stopDto, Stop.class);
        stop = stopRepository.save(stop);
        return mapper.map(stop, StopDTO.class);
    }

    @Override
    public StopDTO updateStop(Long id, StopDTO stopDto) {
        Stop stop = stopRepository.findById(id)
                .orElseThrow(() -> new StopNotFoundException(id));
        mapper.map(stopDto, stop);
        stop = stopRepository.save(stop);
        return mapper.map(stop, StopDTO.class);
    }

    @Override
    public void deleteStop(Long id) {
        stopRepository.deleteById(id);
    }

    @Override
    public TimetableDTO addTimetable(TimetableDTO timetableDto) {
        if (timetableDto.getServiceDay() == null || timetableDto.getRouteId() == null) {
            throw new IllegalArgumentException("serviceDay and routeId are required");
        }

        Route route = routeRepository.findById(timetableDto.getRouteId())
                .orElseThrow(() -> new RouteNotFoundException(timetableDto.getRouteId()));

        
        Timetable timetable = mapper.map(timetableDto, Timetable.class);
        timetable.setRoute(route);
        timetable.setServiceDay(LocalDate.parse(timetableDto.getServiceDay()));

        timetable = timetableRepository.save(timetable);

        
        TimetableDTO result = mapper.map(timetable, TimetableDTO.class);
        result.setRouteId(timetable.getRoute().getId());
        result.setServiceDay(timetable.getServiceDay().toString());

        return result;
    }


    @Override
    public TimetableDTO updateTimetable(Long id, TimetableDTO timetableDto) {
        Timetable timetable = timetableRepository.findById(id)
                .orElseThrow(() -> new TimetableNotFoundException(id));

        if (timetableDto.getRouteId() != null && !timetableDto.getRouteId().equals(timetable.getRoute().getId())) {
            Route route = routeRepository.findById(timetableDto.getRouteId())
                    .orElseThrow(() -> new RouteNotFoundException(timetableDto.getRouteId()));
            timetable.setRoute(route);
        }

        if (timetableDto.getServiceDay() != null) {
            timetable.setServiceDay(LocalDate.parse(timetableDto.getServiceDay()));
        }

        mapper.map(timetableDto, timetable);

        timetable = timetableRepository.save(timetable);

        TimetableDTO result = mapper.map(timetable, TimetableDTO.class);
        result.setRouteId(timetable.getRoute().getId());
        result.setServiceDay(timetable.getServiceDay().toString());

        return result;
    }


    @Override
    public void deleteTimetable(Long id) {
        timetableRepository.deleteById(id);
    }
    
    @Override
    public RouteStopDTO addRouteStop(Long routeId, RouteStopDTO dto) {
        Route route = routeRepository.findById(routeId)
                     .orElseThrow(() -> new RouteNotFoundException(routeId));
        Stop stop = stopRepository.findById(dto.getStopId())
                     .orElseThrow(() -> new StopNotFoundException(dto.getStopId()));

        RouteStop routeStop = new RouteStop();
        routeStop.setRoute(route);
        routeStop.setStop(stop);
        routeStop.setSequence(dto.getSequence());
        routeStop.setDwellSeconds(dto.getDwellSeconds());

        routeStop = routeStopRepository.save(routeStop);
        return mapper.map(routeStop, RouteStopDTO.class);
    }
    
    @Override
    public List<EtaResponseDTO> updateEtaFromTelemetry(TelemetryDTO telemetry) {
        Long routeId = telemetry.getRouteId();
        if (routeId == null) throw new RuntimeException("Telemetry missing routeId");

        List<RouteStop> routeStops = routeStopRepository.findByRoute_IdOrderBySequence(routeId);

        List<EtaResponseDTO> etaResponses = routeStops.stream()
                .map(rs -> new EtaResponseDTO(routeId, rs.getStop().getId(), 300))
                .collect(Collectors.toList());

        
        etaResponses.forEach(eta -> System.out.println(
                "Route " + eta.getRouteId() + " Stop " + eta.getStopId() + " ETA " + eta.getEtaSeconds() + " sec"));

        return etaResponses;
    }

    @Override
    public List<EtaResponseDTO> getETA(Long routeId, Long stopId) {
        
        return List.of(new EtaResponseDTO(routeId, stopId, 300));
    }
}
