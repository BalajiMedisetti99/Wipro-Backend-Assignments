package com.transport.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.transport.constants.Mode;
import com.transport.dto.EtaResponseDTO;
import com.transport.dto.RouteDTO;
import com.transport.dto.RouteStopDTO;
import com.transport.dto.StopDTO;
import com.transport.dto.TelemetryDTO;
import com.transport.dto.TimetableDTO;

public interface RouteService {
	
	
    Page<RouteDTO> getRoutes(Mode mode, boolean active, Pageable pageable);
    RouteDTO getRoute(Long id);
    List<StopDTO> getStopsNear(double lat, double lon, double radius);
    List<RouteStopDTO> getRouteStops(Long routeId);
    List<TimetableDTO> getTimetable(Long routeId, LocalDate serviceDay);

    RouteDTO addRoute(RouteDTO routeDto);
    RouteDTO updateRoute(Long id, RouteDTO routeDto);
    void deleteRoute(Long id);

    StopDTO addStop(StopDTO stopDto);
    StopDTO updateStop(Long id, StopDTO stopDto);
    void deleteStop(Long id);

    TimetableDTO addTimetable(TimetableDTO timetableDto);
    TimetableDTO updateTimetable(Long id, TimetableDTO timetableDto);
    void deleteTimetable(Long id);
    
    RouteStopDTO addRouteStop(Long routeId, RouteStopDTO routeStopDto);
    
    List<EtaResponseDTO> updateEtaFromTelemetry(TelemetryDTO telemetry);

    List<EtaResponseDTO> getETA(Long routeId, Long stopId);

}
