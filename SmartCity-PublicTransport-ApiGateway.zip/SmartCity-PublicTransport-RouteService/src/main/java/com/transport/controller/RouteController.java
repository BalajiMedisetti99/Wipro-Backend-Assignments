package com.transport.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.transport.constants.Mode;
import com.transport.dto.EtaResponseDTO;
import com.transport.dto.RouteDTO;
import com.transport.dto.RouteStopDTO;
import com.transport.dto.StopDTO;
import com.transport.dto.TelemetryDTO;
import com.transport.dto.TimetableDTO;
import com.transport.service.RouteService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/routes")
@RequiredArgsConstructor
public class RouteController {

    private final RouteService routeService;

    @GetMapping
    public Page<RouteDTO> getRoutes(@RequestParam(required = false) Mode mode,
                                    @RequestParam(required = false, defaultValue = "true") boolean active,
                                    Pageable pageable) {
        return routeService.getRoutes(mode, active, pageable);
    }
    @GetMapping("/{id}")
    public RouteDTO getRoute(@PathVariable Long id) {
        return routeService.getRoute(id);
    }

    @GetMapping("/stops")
    public List<StopDTO> getStopsNear(@RequestParam double lat,
                                      @RequestParam double lon,
                                      @RequestParam double radius) {
        return routeService.getStopsNear(lat, lon, radius);
    }

    @GetMapping("/{id}/stops")
    public List<RouteStopDTO> getRouteStops(@PathVariable Long id) {
        return routeService.getRouteStops(id);
    }

    @GetMapping("/{id}/timetable")
    public List<TimetableDTO> getTimetable(@PathVariable Long id,
                                           @RequestParam String date) {
        LocalDate serviceDay = LocalDate.parse(date);
        return routeService.getTimetable(id, serviceDay);
    }


    @PostMapping
    public RouteDTO addRoute(@RequestBody RouteDTO dto) {
        return routeService.addRoute(dto);
    }

    @PutMapping("/{id}")
    public RouteDTO updateRoute(@PathVariable Long id, @RequestBody RouteDTO dto) {
        return routeService.updateRoute(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deleteRoute(@PathVariable Long id) {
        routeService.deleteRoute(id);
    }

    @PostMapping("/stops")
    public StopDTO addStop(@RequestBody StopDTO dto) {
        return routeService.addStop(dto);
    }

    @PutMapping("/stops/{id}")
    public StopDTO updateStop(@PathVariable Long id, @RequestBody StopDTO dto) {
        return routeService.updateStop(id, dto);
    }

    @DeleteMapping("/stops/{id}")
    public void deleteStop(@PathVariable Long id) {
        routeService.deleteStop(id);
    }

    @PostMapping("/timetables")
    public ResponseEntity<TimetableDTO> addTimetable(@Valid @RequestBody TimetableDTO dto) {
        TimetableDTO created = routeService.addTimetable(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/timetables/{id}")
    public ResponseEntity<TimetableDTO> updateTimetable(@PathVariable Long id,
                                                        @Valid @RequestBody TimetableDTO dto) {
        TimetableDTO updated = routeService.updateTimetable(id, dto);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/timetables/{id}")
    public ResponseEntity<Void> deleteTimetable(@PathVariable Long id) {
        routeService.deleteTimetable(id);
        return ResponseEntity.noContent().build();
    }
    
    @PostMapping("/{routeId}/stops")
    public RouteStopDTO addRouteStop(@PathVariable Long routeId,
                                     @RequestBody RouteStopDTO routeStopDto) {
        return routeService.addRouteStop(routeId, routeStopDto);
    }
    
    @PostMapping("/eta")
    public ResponseEntity<List<EtaResponseDTO>> updateEtaFromTelemetry(@RequestBody TelemetryDTO telemetry) {
        List<EtaResponseDTO> etas = routeService.updateEtaFromTelemetry(telemetry);
        return ResponseEntity.ok(etas);
    }

    @GetMapping("/{routeId}/stops/{stopId}/eta")
    public ResponseEntity<List<EtaResponseDTO>> getETA(@PathVariable Long routeId,
                                                       @PathVariable Long stopId) {
        List<EtaResponseDTO> etas = routeService.getETA(routeId, stopId);
        return ResponseEntity.ok(etas);
    }
}