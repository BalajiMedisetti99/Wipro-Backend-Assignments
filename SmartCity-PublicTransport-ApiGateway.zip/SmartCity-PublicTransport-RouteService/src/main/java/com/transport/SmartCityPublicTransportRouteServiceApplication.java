package com.transport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartCityPublicTransportRouteServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartCityPublicTransportRouteServiceApplication.class, args);
	}

}
