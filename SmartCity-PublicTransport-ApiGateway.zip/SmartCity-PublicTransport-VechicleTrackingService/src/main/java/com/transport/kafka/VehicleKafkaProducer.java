package com.transport.kafka;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.transport.dto.TelemetryDTO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class VehicleKafkaProducer {

    private final KafkaTemplate<String, Object> kafkaTemplate;

    private static final String TOPIC = "vehicle-updates";

    public void publishTelemetry(TelemetryDTO telemetry) {
        kafkaTemplate.send(TOPIC, telemetry.getVehicleId(), telemetry);
    }
}