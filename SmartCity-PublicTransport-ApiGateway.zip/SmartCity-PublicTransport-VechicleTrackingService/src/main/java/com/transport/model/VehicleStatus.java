package com.transport.model;

import java.time.Instant;

import com.transport.constants.VehicleState;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Version;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VehicleStatus {

    @Id
    private String vehicleId;

    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    private Vehicle vehicle;

    private Instant lastSeenTs;

    @Enumerated(EnumType.STRING)
    private VehicleState state;

    private int delaySec;
    
    @Version
    private Integer version;
}