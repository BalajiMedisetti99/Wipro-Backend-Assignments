package com.transport.service.impl;


import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.kafka.common.errors.ResourceNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.transport.constants.VehicleState;
import com.transport.dto.EtaResponseDTO;
import com.transport.dto.TelemetryDTO;
import com.transport.dto.VehicleDTO;
import com.transport.dto.VehiclePositionDTO;
import com.transport.dto.VehicleStatusDTO;
import com.transport.kafka.VehicleKafkaProducer;
import com.transport.model.Vehicle;
import com.transport.model.VehiclePosition;
import com.transport.model.VehicleStatus;
import com.transport.repository.VehiclePositionRepository;
import com.transport.repository.VehicleRepository;
import com.transport.repository.VehicleStatusRepository;
import com.transport.service.VehicleService;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class VehicleServiceImpl implements VehicleService {

    private final VehicleRepository vehicleRepository;
    private final VehiclePositionRepository positionRepository;
    private final VehicleStatusRepository statusRepository;
    private final ModelMapper mapper;
    private final VehicleKafkaProducer kafkaProducer;

    @Transactional
    @Override
    public VehiclePositionDTO ingestTelemetry(VehiclePositionDTO dto) {
        Vehicle vehicle = vehicleRepository.findById(dto.getVehicleId())
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found"));

        VehiclePosition position = VehiclePosition.builder()
                .vehicle(vehicle)
                .ts(dto.getTs())
                .lat(dto.getLat())
                .lon(dto.getLon())
                .speed(dto.getSpeed())
                .heading(dto.getHeading())
                .accuracyM(dto.getAccuracyM())
                .build();
        positionRepository.save(position);

        VehicleStatus status = statusRepository.findById(vehicle.getId())
                .orElseGet(() -> VehicleStatus.builder()
                        .vehicle(vehicle)
                        .vehicleId(vehicle.getId())
                        .state(VehicleState.IN_SERVICE)
                        .lastSeenTs(dto.getTs())
                        .delaySec(0)
                        .build());

        status.setLastSeenTs(dto.getTs());
        status.setState(VehicleState.IN_SERVICE);
        statusRepository.save(status);

        TelemetryDTO telemetry = TelemetryDTO.builder()
                .vehicleId(vehicle.getId())
                .lat(dto.getLat())
                .lon(dto.getLon())
                .speed(dto.getSpeed())
                .heading(dto.getHeading())
                .accuracyM(dto.getAccuracyM())
                .ts(dto.getTs())
                .build();
        kafkaProducer.publishTelemetry(telemetry);

        return mapper.map(position, VehiclePositionDTO.class);
    }

    @Override
    public VehiclePositionDTO getCurrentPosition(String vehicleId) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found: " + vehicleId));

        VehiclePosition position = positionRepository.findTopByVehicleOrderByTsDesc(vehicle)
                .orElseThrow(() -> new ResourceNotFoundException("No positions found for vehicle: " + vehicleId));

        return mapper.map(position, VehiclePositionDTO.class);
    }

    @Override
    public VehicleStatusDTO getVehicleStatus(String vehicleId) {
        VehicleStatus status = statusRepository.findById(vehicleId)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle status not found: " + vehicleId));

        return mapper.map(status, VehicleStatusDTO.class);
    }
    @Override
    public List<VehiclePositionDTO> getVehiclePositions(String vehicleId, Instant from, Instant to) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found: " + vehicleId));

        List<VehiclePosition> positions = positionRepository.findAll().stream()
                .filter(p -> p.getVehicle().equals(vehicle) && !p.getTs().isBefore(from) && !p.getTs().isAfter(to))
                .collect(Collectors.toList());

        return positions.stream()
                .map(p -> mapper.map(p, VehiclePositionDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<EtaResponseDTO> getETA(Long routeId, Long stopId) {
        
        return List.of(new EtaResponseDTO(routeId, stopId, 300));
    }
    @Override
    public VehicleDTO registerVehicle(VehicleDTO vehicleDTO) {

        if(vehicleRepository.existsById(vehicleDTO.getId())) {
            throw new IllegalArgumentException("Vehicle already exists: " + vehicleDTO.getId());
        }

        Vehicle vehicle = mapper.map(vehicleDTO, Vehicle.class);

        
        vehicle = vehicleRepository.save(vehicle);

       
        return mapper.map(vehicle, VehicleDTO.class);
    }


}