package com.transport.service;

import java.time.Instant;
import java.util.List;

import com.transport.dto.EtaResponseDTO;
import com.transport.dto.VehicleDTO;
import com.transport.dto.VehiclePositionDTO;
import com.transport.dto.VehicleStatusDTO;

public interface VehicleService {
	
    VehiclePositionDTO ingestTelemetry(VehiclePositionDTO positionDTO);
    VehiclePositionDTO getCurrentPosition(String vehicleId);
    VehicleStatusDTO getVehicleStatus(String vehicleId);
    List<VehiclePositionDTO> getVehiclePositions(String vehicleId, Instant from, Instant to);
    List<EtaResponseDTO> getETA(Long routeId, Long stopId);
    VehicleDTO registerVehicle(VehicleDTO vehicleDTO);

}
