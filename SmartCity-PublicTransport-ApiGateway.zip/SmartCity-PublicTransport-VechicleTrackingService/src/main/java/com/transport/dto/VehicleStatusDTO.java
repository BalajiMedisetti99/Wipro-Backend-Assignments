package com.transport.dto;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VehicleStatusDTO {
    private String vehicleId;
    private Instant lastSeenTs;
    private String state;
    private int delaySec;
    private Integer version;
}
