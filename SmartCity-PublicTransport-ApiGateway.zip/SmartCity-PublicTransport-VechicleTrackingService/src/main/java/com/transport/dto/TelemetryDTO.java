package com.transport.dto;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TelemetryDTO {
    private String vehicleId;
    private Long routeId;
    private Instant ts;
    private double lat;
    private double lon;
    private double speed;
    private double heading;
    private double accuracyM;
}
