package com.transport.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleDTO {
	
	private String id; 

    private String fleetCode;

    private Long routeId;

    private int capacity;
    
    private String features;


}
