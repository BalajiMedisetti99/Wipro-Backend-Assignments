package com.transport.constants;

public enum VehicleState {
    IN_SERVICE,
    OUT_OF_SERVICE,
    DELAYED
}
