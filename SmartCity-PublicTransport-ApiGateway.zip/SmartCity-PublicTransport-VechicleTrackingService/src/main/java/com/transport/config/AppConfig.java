package com.transport.config;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.transport.dto.VehicleStatusDTO;
import com.transport.model.VehicleStatus;

@Configuration
public class AppConfig {
	
	@Bean
	public ModelMapper modelMapper() {
	    ModelMapper mapper = new ModelMapper();

        
	    mapper.addMappings(new PropertyMap<VehicleStatus, VehicleStatusDTO>() {
            @Override
            protected void configure() {
                map().setVehicleId(source.getVehicleId());
            }
        });


	    return mapper;
	}


}
