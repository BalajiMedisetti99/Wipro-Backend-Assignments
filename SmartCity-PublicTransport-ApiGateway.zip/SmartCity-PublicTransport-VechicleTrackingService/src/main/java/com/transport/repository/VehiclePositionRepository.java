package com.transport.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.transport.model.Vehicle;
import com.transport.model.VehiclePosition;

@Repository
public interface VehiclePositionRepository extends JpaRepository<VehiclePosition, Long> {
    Optional<VehiclePosition> findTopByVehicleOrderByTsDesc(Vehicle vehicle);
}
