package com.transport.controller;

import java.time.Instant;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.transport.dto.EtaResponseDTO;
import com.transport.dto.VehicleDTO;
import com.transport.dto.VehiclePositionDTO;
import com.transport.dto.VehicleStatusDTO;
import com.transport.service.VehicleService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/vehicles")
@RequiredArgsConstructor
public class VehicleController {

    private final VehicleService vehicleService;

    @PostMapping("/telemetry")
    public VehiclePositionDTO ingestTelemetry(@RequestBody VehiclePositionDTO telemetry) {
        return vehicleService.ingestTelemetry(telemetry);
    }

    @GetMapping("/{id}/position")
    public VehiclePositionDTO getCurrentPosition(@PathVariable String id) {
        return vehicleService.getCurrentPosition(id);
    }

    @GetMapping("/{id}/status")
    public VehicleStatusDTO getVehicleStatus(@PathVariable String id) {
        return vehicleService.getVehicleStatus(id);
    }

    @GetMapping("/{id}/positions")
    public List<VehiclePositionDTO> getVehiclePositions(
            @PathVariable String id,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to) {
        return vehicleService.getVehiclePositions(id, from, to);
    }

    @GetMapping("/routes/{routeId}/eta")
    public List<EtaResponseDTO> getETA(
            @PathVariable Long routeId,
            @RequestParam Long stopId) {
        return vehicleService.getETA(routeId, stopId);
    }
    @PostMapping("/register")
    public VehicleDTO registerVehicle(@RequestBody VehicleDTO vehicleDTO) {
        return vehicleService.registerVehicle(vehicleDTO);
    }
}