package com.example.medical.records_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalRecordsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
