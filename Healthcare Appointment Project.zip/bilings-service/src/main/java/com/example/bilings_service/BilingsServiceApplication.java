package com.example.bilings_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BilingsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BilingsServiceApplication.class, args);
	}

}
