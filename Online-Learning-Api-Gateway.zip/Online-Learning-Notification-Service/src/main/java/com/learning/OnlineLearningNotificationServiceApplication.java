package com.learning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineLearningNotificationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineLearningNotificationServiceApplication.class, args);
	}

}
