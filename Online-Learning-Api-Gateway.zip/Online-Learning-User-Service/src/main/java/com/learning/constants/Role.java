package com.learning.constants;



public enum Role {
	
	STUDENT,
	TEACHER,
	ADMIN

}
